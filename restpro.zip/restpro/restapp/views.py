from django.shortcuts import render, get_object_or_404, get_list_or_404
from django.http import HttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from restapp.models import Employee
from restapp.serializers import EmployeeSerializer

# Create your views here.

class EmployeeList(APIView):
    def get(self, request):
        lst = get_list_or_404(Employee)
        slst = EmployeeSerializer(lst, many = True)
        return Response(slst.data)
    def post(self):
        sobj = EmployeeSerializer(data = request.data)
        if sobj.is_valid():
           sobj.save()
           return Response(sobj.data, status = status.HTTP_201_CREATED)
        else:
            return Response(sobj.errors, status = status.HTTP_400_BAD_REQUEST)